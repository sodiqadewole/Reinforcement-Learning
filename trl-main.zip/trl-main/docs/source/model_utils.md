# Model Utilities

## clone_chat_template

[[autodoc]] clone_chat_template

## get_act_offloading_ctx_manager

[[autodoc]] models.get_act_offloading_ctx_manager
